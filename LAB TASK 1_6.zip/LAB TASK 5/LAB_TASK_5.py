import cv2
import numpy as np

# --- STEP 1: Creating a Dummy Image (Reading/Generation) ---
# Manual Topic: Reading Images 
# Hum 512x512 ka black canvas bana rahe hain taake koi external file na chahiye ho
img = np.zeros((512, 512, 3), np.uint8)
print("Step 1: Black Canvas (Image) Created successfully.")

# --- STEP 2: Drawing Shapes (Drawing Shapes) ---
# Manual Topic: Drawing Shapes (Line, Rectangle, Circle, Text) 

# 1. Line draw karna (Green color)
# Syntax: cv2.line(image, start_point, end_point, color, thickness)
cv2.line(img, (0, 0), (511, 511), (0, 255, 0), 5)

# 2. Rectangle draw karna (Blue color)
# Syntax: cv2.rectangle(image, top_left, bottom_right, color, thickness)
cv2.rectangle(img, (384, 0), (510, 128), (255, 0, 0), 3)

# 3. Circle draw karna (Red color)
# Syntax: cv2.circle(image, center, radius, color, thickness)
cv2.circle(img, (447, 63), 63, (0, 0, 255), -1) # -1 means fill the circle

# 4. Text likhna (White color)
# Syntax: cv2.putText(image, text, origin, font, scale, color, thickness)
font = cv2.FONT_HERSHEY_SIMPLEX
cv2.putText(img, 'OpenCV Lab 5', (10, 500), font, 2, (255, 255, 255), 2, cv2.LINE_AA)

print("Step 2: Shapes and Text Drawn.")

# --- STEP 3: Image Processing (Resizing & Color Space) ---
# Manual Topic: Resizing & Color Spaces 

# Resize karna (half size)
resized_img = cv2.resize(img, (256, 256)) 

# Color convert karna (BGR to Grayscale)
gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

print("Step 3: Image Resized and Converted to Grayscale.")

# --- STEP 4: Edge Detection (Canny) ---
# Manual Topic: Edge Detection 
edges = cv2.Canny(img, 100, 200)

# --- STEP 5: Displaying & Saving ---
# Manual Topic: Displaying & Writing Images 

# Original Image dikhana
cv2.imshow("Original with Shapes", img)

# Edges dikhana
cv2.imshow("Edge Detection", edges)

# Images ko save karna
cv2.imwrite("lab5_output.jpg", img)
cv2.imwrite("lab5_edges.jpg", edges)
print("Step 5: Images Displayed and Saved as 'lab5_output.jpg'.")

# Window close karne ka intezar (Wait for any key)
cv2.waitKey(0)
cv2.destroyAllWindows()