def dfs_water_jug(capacity_x, capacity_y, goal):

    stack = [((0, 0), [])]
    
    visited = set()

    print(f"--- Solving Water Jug Problem ({capacity_x}L, {capacity_y}L) for Goal: {goal}L ---")
    
    while stack:

        (x, y), path = stack.pop()

        if (x, y) in visited:
            continue
        visited.add((x, y))

        if x == goal or y == goal:
            print("\nSolution Found!")
            print("Rules Applied at Each Step:")
            for i, step in enumerate(path):
                print(f"Step {i+1}: {step}")
            print(f"Final State: ({x}, {y})") # (Jug1 amount, Jug2 amount)
            return

        if x < capacity_x:
            stack.append(((capacity_x, y), path + [f"Fill Jug 1 ({capacity_x}L)"]))

        if y < capacity_y:
            stack.append(((x, capacity_y), path + [f"Fill Jug 2 ({capacity_y}L)"]))

        if x > 0:
            stack.append(((0, y), path + ["Empty Jug 1"]))

        if y > 0:
            stack.append(((x, 0), path + ["Empty Jug 2"]))

        if x > 0 and y < capacity_y:
            amount = min(x, capacity_y - y)
            stack.append(((x - amount, y + amount), path + ["Pour Jug 1 -> Jug 2"]))

        if y > 0 and x < capacity_x:
            amount = min(y, capacity_x - x)
            stack.append(((x + amount, y - amount), path + ["Pour Jug 2 -> Jug 1"]))

    print("No solution found.")

dfs_water_jug(4, 3, 2)