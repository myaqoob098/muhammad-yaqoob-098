import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split

train_data = pd.read_csv('train.csv')
test_data = pd.read_csv('test.csv')

features = ['CryoSleep', 'Age', 'VIP', 'RoomService', 'FoodCourt', 'ShoppingMall', 'Spa', 'VRDeck']

train_data[features] = train_data[features].fillna(0)
test_data[features] = test_data[features].fillna(0)

for col in features:
    train_data[col] = train_data[col].astype(int)
    test_data[col] = test_data[col].astype(int)

X = train_data[features]
y = train_data['Transported'] 

model = DecisionTreeClassifier(random_state=1)
print("Model train ho raha hai...")
model.fit(X, y)

predictions = model.predict(test_data[features])

output = pd.DataFrame({
    'PassengerId': test_data['PassengerId'],
    'Transported': predictions.astype(bool) 
})

output.to_csv('submission_lab2.csv', index=False)
print("Success! File 'submission_lab2.csv' ban gayi hai.")