import os  # <--- 1. Add this import
from flask import Flask, render_template, request
from utils.explain_tone import analyze_sentiment_with_explanation
from utils.scraper import scrape_latest_news
from charts.visualizer import create_sentiment_chart
from voice.speak import speak_text

app = Flask(__name__)

# <--- 2. Add this block to ensure the folder exists
if not os.path.exists('static'):
    os.makedirs('static')

@app.route('/')
def index():
    news = scrape_latest_news().get("news", [])
    return render_template('index.html', news=news)

@app.route('/result', methods=['POST'])
def result():
    headline = request.form['headline']
    description = request.form.get('description', '')

    combined_text = f"{headline} {description}"

    # Analyze the sentiment and get explanation details
    sentiment, explanation, contrast = analyze_sentiment_with_explanation(combined_text)

    # Generate a chart based on predicted sentiment
    # This will now successfully save into the 'static' folder
    chart_path = create_sentiment_chart(sentiment)

    # Generate speech output
    audio_path = speak_text(f"The sentiment is {sentiment}")

    return render_template(
        'result.html',
        headline=headline,
        description=description,
        sentiment=sentiment,
        explanation=explanation,
        contrast=contrast,
        chart_path=chart_path,
        audio_path=audio_path
    )

if __name__ == '__main__':
    app.run(debug=True)