import matplotlib.pyplot as plt
import os

def create_sentiment_chart(sentiment):
    """
    Create and save a bar chart showing sentiment classification result.
    """

    labels = ['Positive', 'Neutral', 'Negative']
    colors = ['#66b3ff', '#ffcc99', '#ff6666']

    # Initialize scores
    scores = [0.0, 0.0, 0.0]

    if sentiment == 'Positive':
        scores = [0.7, 0.2, 0.1]
    elif sentiment == 'Neutral':
        scores = [0.2, 0.6, 0.2]
    elif sentiment == 'Negative':
        scores = [0.1, 0.2, 0.7]

    # Plot bar chart
    plt.figure(figsize=(6, 4))
    bars = plt.bar(labels, scores, color=colors)

    # Add value labels
    for bar in bars:
        height = bar.get_height()
        plt.text(bar.get_x() + bar.get_width()/2, height + 0.02,
                 f'{height:.2f}', ha='center', va='bottom')

    plt.title("Sentiment Distribution")
    plt.ylim(0, 1)
    plt.ylabel("Relative Score")

    save_path = 'static/sentiment_chart.png'
    plt.tight_layout()
    plt.savefig(save_path)
    plt.close()

    return 'sentiment_chart.png'
