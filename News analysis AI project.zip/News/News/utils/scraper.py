import requests
from bs4 import BeautifulSoup

def scrape_latest_news():
    url = 'https://www.bbc.com/news'
    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')

    news_items = []
    articles = soup.select('a.gs-c-promo-heading')[:5]

    for article in articles:
        title = article.get_text(strip=True)
        link = article.get('href')
        if not link.startswith('http'):
            link = 'https://www.bbc.com' + link

        try:
            article_page = requests.get(link)
            article_soup = BeautifulSoup(article_page.text, 'html.parser')
            summary_tag = article_soup.find('p')
            summary = summary_tag.get_text(strip=True) if summary_tag else "No summary available."
        except:
            summary = "No summary available."

        news_items.append({
            "title": title,
            "summary": summary
        })

    return {"news": news_items}
