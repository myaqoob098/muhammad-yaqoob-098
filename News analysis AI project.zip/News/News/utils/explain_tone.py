from textblob import TextBlob

def analyze_sentiment_with_explanation(text):
    analysis = TextBlob(text)
    polarity = analysis.sentiment.polarity

    if polarity > 0.05:
        sentiment = "positive"
    elif polarity < -0.05:
        sentiment = "negative"
    else:
        sentiment = "neutral"

    # Explanation why the sentiment was selected
    primary_reason = {
        "positive": "The text uses optimistic, encouraging, or uplifting language. Words convey hope, progress, or success.",
        "negative": "The text includes pessimistic or critical language. It discusses problems, risks, or negative outcomes.",
        "neutral": "The language is factual and objective, without showing emotion. It avoids positive or negative wording."
    }

    # Why other sentiments were not selected
    other_reasons = {
        "positive": "It is not negative because the text doesn't express fear, criticism, or frustration. It's not neutral because it clearly conveys optimism.",
        "negative": "It is not positive because the language doesn't include encouragement or praise. It's not neutral because emotional and critical tones are present.",
        "neutral": "It is not positive because it lacks enthusiastic or emotional words. It's not negative because it doesn't express concern or complaint."
    }

    return sentiment, primary_reason[sentiment], other_reasons[sentiment]
