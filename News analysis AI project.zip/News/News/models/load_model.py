
import joblib
import numpy as np

# Load vectorizers and model
vectorizer = joblib.load('tfidf_vectorizer.pkl')
model = joblib.load('xgboost_sentiment_model.pkl')

def clean_text(text):
    return text.lower().strip()

def predict_sentiment(title, description):
    title_clean = clean_text(title)
    desc_clean = clean_text(description)

    title_features = vectorizer.transform([title_clean])

    # Use sparse horizontal stacking to preserve memory
    from scipy.sparse import hstack
    X_input = hstack([title_features])

    expected_shape = model.get_booster().num_features()
    actual_shape = X_input.shape[1]
    if expected_shape != actual_shape:
        raise ValueError(
            f"Shape mismatch detected!\n"
            f"Model expects {expected_shape} features, but input has {actual_shape} features.\n"
            f"➔ Make sure you're using the correct vectorizers from training."
        )

    prediction = model.predict(X_input)
    label_map = {0: 'Negative', 1: 'Neutral', 2: 'Positive'}
    return label_map.get(int(prediction[0]), 'Unknown')
