import pyttsx3
import os

def speak_text(text):
    """Generate a spoken audio file from text."""
    engine = pyttsx3.init()
    audio_path = 'static/voice_output.mp3'

    engine.save_to_file(text, audio_path)
    engine.runAndWait()

    return 'voice_output.mp3'
