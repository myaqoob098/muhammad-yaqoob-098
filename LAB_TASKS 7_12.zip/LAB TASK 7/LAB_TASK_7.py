from flask import Flask, render_template
import requests

app = Flask(__name__)

def get_random_joke():
    
    url = "https://official-joke-api.appspot.com/random_joke"
    
    try:
        response = requests.get(url)
        if response.status_code == 200:
            data = response.json()
           
            return f"{data['setup']} ... {data['punchline']}"
        else:
            return "Error: Joke load nahi hua."
    except:
        return "Error: Internet connection check karein."

@app.route('/')
def index():
    
    joke = get_random_joke()
    return render_template('index.html', joke=joke)

@app.route('/new_joke')
def new_joke():
    joke = get_random_joke()
    return render_template('index.html', joke=joke)

if __name__ == "__main__":
    app.run(debug=True)