from flask import Flask, render_template, request
from sentence_transformers import SentenceTransformer
import faiss
import numpy as np
import re
import os

app = Flask(__name__)

# --- CONFIGURATION ---
DATA_FILE = 'university_data.txt'
MODEL_NAME = 'paraphrase-MiniLM-L6-v2'

print("--- LOADING AI MODEL... ---")
# Model load kar rahe hain
model = SentenceTransformer(MODEL_NAME)

# --- CLEANING FUNCTION ---
def clean_text(text):
    if isinstance(text, str):
        # Allow Alphabets, Numbers, Spaces, and basic symbols
        text = re.sub(r'[^A-Za-z0-9\s\$\.\,]', '', text)
        text = text.lower()
    return text

# --- READ DATA ---
print("--- READING DATA ---")
cleaned_data = []
original_data = []

if os.path.exists(DATA_FILE):
    with open(DATA_FILE, 'r', encoding='utf-8') as f:
        raw_lines = f.readlines()
    
    for line in raw_lines:
        if line.strip():
            original_data.append(line.strip())
            cleaned_data.append(clean_text(line.strip()))
else:
    print("Error: university_data.txt file missing.")
    original_data = ["Data file not found."]
    cleaned_data = ["error"]

# --- TRAINING ---
print(f"--- TRAINING ON {len(cleaned_data)} SENTENCES ---")
if cleaned_data:
    embeddings = model.encode(cleaned_data)
    dimension = embeddings.shape[1]
    index = faiss.IndexFlatL2(dimension)
    index.add(np.array(embeddings))
    print("--- SYSTEM READY (NO RESTRICTIONS) ---")

def retrieve_info(query):
    if not cleaned_data:
        return "System Error: No Data Loaded."

    # 1. User Query Clean karo
    query = clean_text(query)
    
    # 2. Search karo
    query_vector = model.encode([query])
    distances, indices = index.search(query_vector, k=1)
    
    best_idx = indices[0][0]
    
    # Debug print
    print(f"User Asked: {query}")
    print(f"Bot Answer: {original_data[best_idx]}")
    
    # Ye Top Match return karega (No Sorry)
    return original_data[best_idx]

@app.route("/", methods=['GET', 'POST'])
def home():
    answer = ""
    if request.method == 'POST':
        user_query = request.form.get('msg')
        if user_query:
            answer = retrieve_info(user_query)
    return render_template("index.html", answer=answer)

if __name__ == "__main__":
    app.run(debug=True)