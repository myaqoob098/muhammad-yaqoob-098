from flask import Flask, render_template, request, jsonify
from transformers import pipeline

app = Flask(__name__)

print("--- Loading AI Brain (GPT-2)... Please Wait ---")
generator = pipeline('text-generation', model='gpt2')
print("--- AI Ready! ---")

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/generate', methods=['POST'])
def generate_text():
    data = request.json
    prompt = data.get('prompt')
    length = int(data.get('length', 50))
    creativity = float(data.get('creativity', 0.7)) # Temperature setting

    if not prompt:
        return jsonify({'error': 'Please write something!'})

    try:
        result = generator(prompt, max_length=length, num_return_sequences=1, temperature=creativity)
        generated_text = result[0]['generated_text']
        
        return jsonify({'result': generated_text})
    except Exception as e:
        return jsonify({'error': str(e)})

if __name__ == "__main__":
    app.run(debug=True)