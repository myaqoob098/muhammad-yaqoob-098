from flask import Flask, render_template, request
import requests

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def home():
    result = None
    name = ""
    
    if request.method == 'POST':
        name = request.form.get('name')
        if name:

            url = f"https://api.nationalize.io/?name={name}"
            try:
                response = requests.get(url)
                data = response.json()
                
                if data.get('country') and len(data['country']) > 0:
                    country_id = data['country'][0]['country_id']
                    probability = round(data['country'][0]['probability'] * 100, 2)
                    result = f"I am {probability}% sure that '{name}' is from {country_id}!"
                else:
                    result = f"Sorry, I couldn't guess the nationality of '{name}'."
            except:
                result = "Error: Internet check karein."

    return render_template('index.html', result=result, name=name)

if __name__ == "__main__":
    app.run(debug=True)