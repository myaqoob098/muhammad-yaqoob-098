from flask import Flask, render_template, request
import wikipedia

app = Flask(__name__)


uni_responses = {
  
    "hello": "Hi! Welcome to the University Bot. Ask me about Admissions, Fees, or search any Topic.",
    "hi": "Hello! I am ready to help.",
    "salam": "Walaikum Assalam! Kahiye main kya madad kar sakta hoon?",
    "bye": "Goodbye! Have a nice day.",
    
  
    "deadline": "The admission deadline for Fall 2025 is August 30th.",
    "fee": "The tuition fee is $500 per semester.",
    "scholarship": "We offer merit-based scholarships for top 10% students.",
    "programs": "We offer BS in AI, CS, SE, and BBA.",
    "hostel": "Hostels are available for $100/month.",
    "location": "Main Campus, Raiwind Road, Lahore.",
    "contact": "Email: info@university.edu | Phone: +92-123-456789",
    "who made you": "I am an AI Bot created by Muhammad Yaqoob."
}

def get_bot_response(user_text):
   
    query = user_text.lower().strip()

   
    for key in uni_responses:
        if key in query:
            return uni_responses[key]

  
    try:
       
        result = wikipedia.summary(user_text, sentences=2, auto_suggest=False)
        return f"(From Internet): {result}"
    
    except wikipedia.exceptions.DisambiguationError as e:

        return f"Please be specific. Did you mean: {e.options[:3]}?"
    
    except wikipedia.exceptions.PageError:
       
        return "Sorry, I couldn't find exact information on this topic."
    
    except Exception:
        return "My internet connection is interrupting. Please try again."

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/get")
def get_bot_response_route():
    userText = request.args.get('msg')
    return get_bot_response(userText)

if __name__ == "__main__":
    app.run(debug=True)