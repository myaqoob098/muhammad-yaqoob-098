from textblob import TextBlob

def analyze_sentiment(text):
    print(f"\nAnalyzing Text: '{text}'")
    
    blob = TextBlob(text)
    print(f"Tokens: {blob.words}")
    polarity = blob.sentiment.polarity
    if polarity > 0:
        print(f"Sentiment: POSITIVE (Score: {polarity})")
    elif polarity < 0:
        print(f"Sentiment: NEGATIVE (Score: {polarity})")
    else:
        print(f"Sentiment: NEUTRAL (Score: {polarity})")
if __name__ == "__main__":
    print("--- Lab 9: NLP Task Output ---")
    analyze_sentiment("I love programming, it is amazing!")
    analyze_sentiment("This code is full of errors and I hate it.")
    analyze_sentiment("The book is on the table.")